import type { Config } from "tailwindcss";
export default { content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"], theme: { extend: { colors: { navy: "#0B1220", teal: "#14F1C6", gold: "#F5C542", panel: "#141C2B" }, fontFamily: { outfit: ["var(--font-outfit)"], inter: ["var(--font-inter)"] }, borderRadius: { "2xl": "1rem" } } }, plugins: [] } satisfies Config;
