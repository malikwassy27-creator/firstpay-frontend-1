"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { Activity, ArrowDownToLine, CircleUserRound, Gamepad2, LayoutDashboard, LogOut, ShieldCheck, ShieldEllipsis, WalletCards } from "lucide-react";

const playerLinks = [
  { label: "Overview", href: "/lobby", icon: LayoutDashboard },
  { label: "Game room", href: "/lobby#games", icon: Gamepad2 },
  { label: "Wallet", href: "/cashier", icon: WalletCards },
  { label: "Activity", href: "/cashier#activity", icon: Activity },
  { label: "Account", href: "/account", icon: CircleUserRound },
];

export function Shell({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const path = usePathname();
  const router = useRouter();
  const [realityCheck, setRealityCheck] = useState(false);
  const [balances, setBalances] = useState<{ real: string; bonus: string; currency: string } | null>(null);
  const [balanceUpdated, setBalanceUpdated] = useState(false);
  const inPlayerApp = Boolean(user) && path !== "/" && !path.startsWith("/login") && !path.startsWith("/register");

  useEffect(() => {
    if (!user) return;
    const start = Number(sessionStorage.getItem("firstpay-session-start") || Date.now());
    sessionStorage.setItem("firstpay-session-start", String(start));
    const timer = window.setInterval(() => {
      const sessionStart = Number(sessionStorage.getItem("firstpay-session-start") || Date.now());
      if (Date.now() - sessionStart >= 60 * 60_000) setRealityCheck(true);
    }, 15_000);
    return () => window.clearInterval(timer);
  }, [user]);

  useEffect(() => {
    if (!user) { setBalances(null); return; }
    let current = true;
    let pulseTimer: number | undefined;
    const loadBalance = () => api<{ wallet: { real_balance: string; bonus_balance: string; currency: string } }>("/cashier/summary").then((data) => {
      if (current) setBalances({ real: data.wallet.real_balance, bonus: data.wallet.bonus_balance, currency: data.wallet.currency });
    }).catch(() => { if (current) setBalances(null); });
    const refresh = () => {
      void loadBalance();
      setBalanceUpdated(true);
      if (pulseTimer) window.clearTimeout(pulseTimer);
      pulseTimer = window.setTimeout(() => setBalanceUpdated(false), 900);
    };
    void loadBalance();
    window.addEventListener("firstpay:wallet-updated", refresh);
    return () => { current = false; window.removeEventListener("firstpay:wallet-updated", refresh); if (pulseTimer) window.clearTimeout(pulseTimer); };
  }, [user, path]);

  const active = (href: string) => href === "/lobby#games" ? path.startsWith("/games/") : href.includes("#") ? false : path === href || path.startsWith(`${href}/`);
  return <>
    <div className="ambient-glow" aria-hidden="true"><span className="ambient-teal"/><span className="ambient-gold"/></div>
    <header className="app-header">
      <div className="header-brand-wrap">
        <Link href={user ? "/lobby" : "/"} className="brand"><span className="brand-mark">F</span><span>FIRSTPAY <i>PLAY</i></span></Link>
        <span className="header-divider" />
        <nav className="header-nav" aria-label="Main navigation">
          <Link href={user ? "/lobby" : "/login"} className={path === "/lobby" ? "header-nav-link current" : "header-nav-link"}>Lobby</Link>
          <Link href={user ? "/cashier" : "/login"} className={path.startsWith("/cashier") ? "header-nav-link current" : "header-nav-link"}>Cashier</Link>
          <Link href="/responsible-gambling" className={path === "/responsible-gambling" ? "header-nav-link current" : "header-nav-link"}>Responsible play</Link>
        </nav>
      </div>
      <div className="header-actions">
        <Link href="/responsible-gambling" className="quiet-link"><ShieldCheck size={16} /> Play responsibly</Link>
        {user ? <>
          <Link href="/cashier" className={`balance-capsule ${balanceUpdated ? "balance-updated" : ""}`} aria-label="View wallet balances"><span><small>AVAILABLE</small><strong>{balances ? `${balances.currency} ${Number(balances.real).toFixed(2)}` : "—"}</strong></span><i/><span><small>BONUS</small><strong>{balances ? `${balances.currency} ${Number(balances.bonus).toFixed(2)}` : "—"}</strong></span></Link>
          <Link href="/account" className="user-chip"><span className="user-avatar">{user.email.slice(0, 1).toUpperCase()}</span><span className="user-email">Account</span></Link>
          <Button size="sm" variant="ghost" aria-label="Log out" onClick={() => { logout(); router.push("/"); }}><LogOut size={16} /><span className="logout-label">Log out</span></Button>
        </> : <><Link className="quiet-link" href="/login">Log in</Link><Button size="sm" asChild><Link href="/register">Create account</Link></Button></>}
      </div>
    </header>

    {inPlayerApp ? <div className="app-layout">
      <aside className="app-sidebar">
        <p className="side-label">YOUR ACCOUNT</p>
        <nav aria-label="Player navigation" className="side-nav">
          {playerLinks.map(({ label, href, icon: Icon }) => <Link key={href} href={href} className={`side-link ${active(href) ? "is-active" : ""}`}><Icon size={17} /><span>{label}</span>{label === "Wallet" && <span className="side-link-trailing"><ArrowDownToLine size={13} /></span>}</Link>)}
          {user?.role === "ADMIN" && <Link href="/admin" className={`side-link ${active("/admin") ? "is-active" : ""}`}><ShieldEllipsis size={17} /><span>Administration</span></Link>}
        </nav>
        <Link href="/responsible-gambling" className="sidebar-safety"><ShieldCheck size={16}/><span><strong>Play controls</strong><small>Limits and time away</small></span></Link>
      </aside>
      <main className="app-main"><div className="main-inner">{children}</div><footer className="app-footer"><span>Practice credits only · payment processing is disabled</span><div className="footer-links"><Link href="/terms">Terms</Link><Link href="/privacy">Privacy</Link><Link href="/responsible-gambling">Player safety</Link></div></footer></main>
    </div> : <>
      <main className="public-main">{children}</main>
      <footer className="public-footer"><span>Practice credits only · payment processing is disabled</span><div className="footer-links"><Link href="/terms">Terms</Link><Link href="/privacy">Privacy</Link><Link href="/responsible-gambling">Player safety</Link></div></footer>
    </>}

    {realityCheck && <div role="dialog" aria-modal="true" aria-labelledby="reality-title" className="reality-overlay"><div className="reality-dialog"><p className="eyebrow">A MOMENT TO CHECK IN</p><h2 id="reality-title">You’ve been here for an hour.</h2><p>Take a moment to check the time, your spending and how you feel. You can end your session or continue with your limits in mind.</p><div className="reality-actions"><Button variant="outline" onClick={() => { setRealityCheck(false); logout(); router.push("/"); }}>End session</Button><Button onClick={() => { sessionStorage.setItem("firstpay-session-start", String(Date.now())); setRealityCheck(false); }}>Continue</Button></div></div></div>}
  </>;
}
