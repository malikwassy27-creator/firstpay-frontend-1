"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ArrowUpRight, BadgeCheck, Clock3, ShieldCheck } from "lucide-react";
import { Card } from "@/components/ui/card";

export type RecentRound = { id: string; label: string; won: boolean; time: string };

export function useRecentRounds(game: "roulette" | "mines") {
  const [rounds, setRounds] = useState<RecentRound[]>([]);
  useEffect(() => {
    try {
      const stored = sessionStorage.getItem(`firstpay:recent:${game}`);
      if (stored) {
        const parsed: unknown = JSON.parse(stored);
        if (Array.isArray(parsed)) setRounds(parsed.filter((item): item is RecentRound => typeof item?.id === "string" && typeof item?.label === "string" && typeof item?.won === "boolean" && typeof item?.time === "string").slice(0, 5));
      }
    } catch { setRounds([]); }
  }, [game]);
  function remember(round: RecentRound) {
    setRounds(current => {
      const next = [round, ...current.filter(item => item.id !== round.id)].slice(0, 5);
      try { sessionStorage.setItem(`firstpay:recent:${game}`, JSON.stringify(next)); } catch { /* session history is optional */ }
      return next;
    });
  }
  return { rounds, remember };
}

export function GameIntel({ hash, rounds }: { hash?: string; rounds: RecentRound[] }) {
  return <Card className="game-intel-card"><div className="intel-heading"><span className="intel-icon"><ShieldCheck size={17}/></span><div><p className="dashboard-kicker">ROUND DETAILS</p><h2>Fair play & history</h2></div></div>
    <section className="intel-seed"><div className="intel-section-title"><ShieldCheck size={14}/><span>LIVE SERVER SEED HASH</span></div>{hash ? <><code>{hash}</code><p>Committed before the round resolves. Compare this value on the verification page afterwards.</p></> : <p>Start a round to see its server seed commitment here.</p>}</section>
    <section className="intel-history"><div className="intel-section-title"><Clock3 size={14}/><span>RECENT ROUNDS</span></div>{rounds.length ? <ul>{rounds.map(round => <li key={round.id}><span className={`intel-result-dot ${round.won ? "win" : "loss"}`}/><span className="intel-round-label">{round.label}</span><span className="intel-round-time">{round.time}</span><Link href={`/verify/${round.id}`} aria-label={`Verify ${round.label} round`}><ArrowUpRight size={14}/></Link></li>)}</ul> : <div className="intel-empty"><BadgeCheck size={16}/><span>Completed rounds from this browser session will appear here.</span></div>}</section>
    <Link href="/responsible-gambling" className="intel-controls">Your play controls <ArrowUpRight size={13}/></Link>
  </Card>;
}
