"use client";

import Link from "next/link";
import { useState } from "react";
import { ArrowLeft, ArrowRight, BadgeCheck, Bomb, Diamond, LoaderCircle, RotateCcw, ShieldCheck } from "lucide-react";
import { notifyWalletUpdated, post } from "@/lib/api";
import { PlayerOnly } from "@/components/require-auth";
import { Card, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { GameIntel, useRecentRounds } from "@/components/game-intel";

type Round = { round_id: string; server_seed_hash: string };
type Outcome = { mine?: boolean; multiplier?: string; won?: boolean; payout?: string };
export default function Mines() {
  const [amount, setAmount] = useState("1.00");
  const [round, setRound] = useState<Round | null>(null);
  const [cells, setCells] = useState<Record<number, boolean>>({});
  const [multiplier, setMultiplier] = useState("1.0000");
  const [finished, setFinished] = useState(false);
  const [outcome, setOutcome] = useState<Outcome | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [key, setKey] = useState("");
  const [pendingCell, setPendingCell] = useState<number | null>(null);
  const { rounds, remember } = useRecentRounds("mines");

  async function start() {
    setBusy(true); setError(""); setOutcome(null);
    try {
      const committed = await post<Round>("/games/mines/commit", { client_seed: `web-${crypto.randomUUID()}` });
      setRound(committed); setCells({}); setMultiplier("1.0000"); setFinished(false); setKey(crypto.randomUUID());
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not prepare the round. Check your connection and try again."); }
    finally { setBusy(false); }
  }
  async function reveal(cell: number) {
    if (!round || finished || busy || cells[cell] !== undefined) return;
    setBusy(true); setError("");
    setPendingCell(cell);
    try {
      const response = await post<{ result: Outcome; completed: boolean }>("/games/mines/reveal", { round_id: round.round_id, cell, amount, idempotency_key: key });
      notifyWalletUpdated();
      setCells(previous => ({ ...previous, [cell]: Boolean(response.result.mine) }));
      if (response.result.multiplier) setMultiplier(response.result.multiplier);
      if (response.completed) { setFinished(true); setOutcome(response.result); remember({ id: round.round_id, label: `${safeCount + (response.result.mine ? 0 : 1)} safe · ${response.result.won ? "Win" : "Mine"}`, won: Boolean(response.result.won), time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }); }
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not reveal that tile. Try again."); }
    finally { setPendingCell(null); setBusy(false); }
  }
  async function cashout() {
    if (!round || safeCount === 0) return;
    setBusy(true); setError("");
    try {
      const response = await post<{ result: Outcome; completed: boolean }>("/games/mines/cashout", { round_id: round.round_id, idempotency_key: key });
      setFinished(true); setOutcome(response.result);
      notifyWalletUpdated();
      remember({ id: round.round_id, label: `${safeCount} safe · Cashed out`, won: true, time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) });
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not cash out. Your round is still active."); }
    finally { setBusy(false); }
  }
  function reset() { setRound(null); setCells({}); setFinished(false); setOutcome(null); setError(""); }
  const safeCount = Object.values(cells).filter(value => !value).length;
  const revealed = Object.keys(cells).length;

  return <PlayerOnly>
    <Link href="/lobby#games" className="game-back"><ArrowLeft size={15}/> All games</Link>
<div className="game-page-head"><div><p className="dashboard-kicker">GAME ROOM / TABLE 02</p><h1>Mines</h1><p>Find safe tiles, build your multiplier and cash out before you hit a mine.</p></div></div>
    <div className="mines-layout">
      <Card className="mines-board-card">
        <div className="mines-board-head"><div><p className="dashboard-kicker">5 × 5 GRID · 3 MINES</p><h2>{finished ? "Round complete" : round ? "Choose your next tile" : "A fresh board"}</h2></div><div className="multiplier-badge"><span>CURRENT MULTIPLIER</span><strong>{multiplier}×</strong></div></div>
        {round && <div className="mines-commitment"><div><ShieldCheck size={14}/> SERVER SEED COMMITTED</div><code>{round.server_seed_hash}</code></div>}
        <div className="mines-board" aria-label="Mines game board">{Array.from({ length: 25 }, (_, cell) => {
          const revealedCell = cells[cell] !== undefined;
          const pending = pendingCell === cell;
          return <button key={cell} type="button" aria-label={pending ? `Revealing tile ${cell + 1}` : revealedCell ? `Tile ${cell + 1}, ${cells[cell] ? "mine" : "safe"}` : `Reveal tile ${cell + 1}`} aria-busy={pending} aria-pressed={revealedCell} disabled={!round || finished || busy || revealedCell} onClick={() => void reveal(cell)} className={`mine-tile transition-all duration-300 ${pending ? "tile-pending" : revealedCell ? (cells[cell] ? "tile-mine" : "tile-safe") : ""}`}>
            {pending ? <LoaderCircle size={21} className="animate-spin"/> : revealedCell ? cells[cell] ? <Bomb size={21}/> : <Diamond size={20}/> : <span className="tile-hidden-mark"/>}
          </button>;
        })}</div>
        {error && <div className="notice-error" role="alert">{error}</div>}
        {finished && <div className={`mines-outcome ${outcome?.won ? "outcome-win" : "outcome-loss"}`}><div><strong>{outcome?.won ? `Cashed out · ${outcome.payout ?? ""} EUR` : "Mine hit · round over"}</strong><span>{safeCount} safe tile{safeCount === 1 ? "" : "s"} · {outcome?.multiplier ?? multiplier}×</span></div><Link href={`/verify/${round?.round_id}`} className="verify-action">Verify round <ArrowRight size={14}/></Link></div>}
      </Card>
      <div className="game-side-column"><Card className="mines-control-card">
        <div className="bet-panel-heading"><div><p className="dashboard-kicker">ROUND CONTROLS</p><CardTitle className="mt-2">{round ? "Your run" : "Set your stake"}</CardTitle></div><span className="round-icon"><Bomb size={18}/></span></div>
        {!round ? <>
          <div className="mines-rules"><span><i>01</i> Start with your stake</span><span><i>02</i> Reveal safe tiles</span><span><i>03</i> Cash out when ready</span></div>
          <div className="bet-field"><label className="label" htmlFor="mines-amount">Stake amount <span>EUR</span></label><div className="amount-control"><button type="button" onClick={() => setAmount((Math.max(.1, Number(amount) / 2)).toFixed(2))}>½</button><input id="mines-amount" inputMode="decimal" type="number" min="0.01" step="0.01" value={amount} onChange={event => setAmount(event.target.value)} /><button type="button" onClick={() => setAmount((Number(amount) * 2).toFixed(2))}>2×</button></div></div>
          <Button className="w-full game-primary-action" disabled={busy || !/^\d+(\.\d{1,2})?$/.test(amount) || Number(amount) <= 0} onClick={() => void start()}>{busy ? "Preparing commitment…" : "Prepare board"}<ArrowRight size={16}/></Button>
          <p className="mines-small-note">Your stake is debited when you reveal your first tile. Three mine positions are fixed by the server before the round begins.</p>
        </> : <>
          <div className="mines-stat-row"><span>Safe picks</span><strong>{safeCount}</strong></div><div className="mines-stat-row"><span>Revealed</span><strong>{revealed} / 25</strong></div><div className="mines-stat-row"><span>Potential payout</span><strong>{(Number(amount) * Number(multiplier)).toFixed(2)} EUR</strong></div>
          {revealed === 0 && <><div className="bet-field"><label className="label" htmlFor="mines-adjust-amount">Stake amount <span>EUR</span></label><div className="amount-control"><button type="button" onClick={() => setAmount((Math.max(.1, Number(amount) / 2)).toFixed(2))} disabled={busy}>½</button><input id="mines-adjust-amount" inputMode="decimal" type="number" min="0.01" step="0.01" value={amount} onChange={event => setAmount(event.target.value)} disabled={busy}/><button type="button" onClick={() => setAmount((Number(amount) * 2).toFixed(2))} disabled={busy}>2×</button></div></div><Button className="w-full mines-discard" variant="ghost" disabled={busy} onClick={reset}>Discard unstarted board</Button></>}
          {!finished ? <Button className="w-full game-primary-action cashout-action" aria-busy={busy} disabled={busy || safeCount === 0} onClick={() => void cashout()}>{busy ? <><span className="button-spinner"/> Securing payout…</> : safeCount ? "Cash out now" : "Reveal a safe tile first"}<ArrowRight size={16}/></Button> : <Button className="w-full game-primary-action" variant="outline" onClick={reset}><RotateCcw size={15}/> New round</Button>}
          {finished && <Link href={`/verify/${round.round_id}`} className="verify-link"><BadgeCheck size={14}/> View fairness proof</Link>}
        </>}
        <div className="bet-security"><BadgeCheck size={14}/><span>Board positions come from your committed server seed and are verified after the round.</span></div>
      </Card><GameIntel hash={round?.server_seed_hash} rounds={rounds}/></div>
    </div>
  </PlayerOnly>;
}
