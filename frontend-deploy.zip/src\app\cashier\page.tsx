"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";
import { ArrowDownLeft, ArrowUpRight, BadgeCheck, Clock3, CreditCard, RefreshCw, WalletCards } from "lucide-react";
import { api, post } from "@/lib/api";
import { PlayerOnly } from "@/components/require-auth";
import { Card, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

type Summary = { wallet: { real_balance: string; bonus_balance: string; currency: string }; transactions: { id: string; type: string; status: string; created_at: string; entries: { direction: string; amount: string; currency: string }[] }[]; withdrawals: { id: string; amount: string; status: string; createdAt: string }[]; deposits: { id: string; amount: string; status: string; createdAt?: string }[] };
const money = (value: string, currency: string) => new Intl.NumberFormat(undefined, { style: "currency", currency, minimumFractionDigits: 2 }).format(Number(value));

export default function Cashier() {
  const [data, setData] = useState<Summary | null>(null);
  const [depositAmount, setDepositAmount] = useState("25.00");
  const [withdrawAmount, setWithdrawAmount] = useState("25.00");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState<"deposit" | "withdraw" | "refresh" | null>(null);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    setBusy("refresh"); setError("");
    try { setData(await api<Summary>("/cashier/summary")); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Wallet details could not be loaded."); }
    finally { setLoading(false); setBusy(null); }
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);

  async function submit(event: FormEvent, kind: "deposit" | "withdraw") {
    event.preventDefault(); setBusy(kind); setError(""); setNotice("");
    const amount = kind === "deposit" ? depositAmount : withdrawAmount;
    try {
      const result = await post<{ status?: string }>(`/cashier/${kind}`, { amount, idempotency_key: crypto.randomUUID() });
      setNotice(kind === "deposit" ? "Practice credits were added to your balance." : `Your withdrawal request is ${result.status ?? "PENDING"}. The balance changes only after admin approval.`);
      await refresh();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "The request could not be completed. Please try again."); setBusy(null); }
  }
  const currency = data?.wallet.currency ?? "EUR";
  const amountInput = (id: string, value: string, setValue: (value: string) => void, disabled: boolean) => <div className="wallet-amount-input"><span>€</span><input id={id} type="number" inputMode="decimal" min="0.01" step="0.01" required value={value} onChange={event => setValue(event.target.value)} disabled={disabled} /><span className="amount-currency">EUR</span></div>;

  return <PlayerOnly>
    <div className="dashboard-heading"><div><p className="dashboard-kicker">ACCOUNT / WALLET</p><h1>Your wallet</h1><p className="dashboard-subtitle">Review your practice balance and every wallet movement.</p></div><Button size="sm" variant="outline" onClick={() => void refresh()} disabled={busy === "refresh"}><RefreshCw size={14} className={busy === "refresh" ? "animate-spin" : ""}/> Refresh</Button></div>
    {error && <div role="alert" className="notice-error">{error}<Button size="sm" variant="outline" onClick={() => void refresh()}>Try again</Button></div>}
    {notice && <div role="status" className="notice-success"><BadgeCheck size={15}/>{notice}</div>}
    <section className="wallet-balance-grid" aria-label="Wallet balance">
      <Card className="wallet-total-card"><div className="balance-label"><span className="balance-icon"><WalletCards size={17}/></span><span>PRACTICE BALANCE</span></div><p className="wallet-large-balance">{loading ? "Loading…" : data ? money(data.wallet.real_balance, currency) : "—"}</p><p className="balance-caption">Practice credits · {currency}</p><div className="wallet-balance-foot"><span>Bonus balance</span><strong>{loading ? "—" : data ? money(data.wallet.bonus_balance, currency) : "—"}</strong></div></Card>
      <Card className="wallet-policy-card"><div className="policy-icon"><ShieldCheckIcon/></div><p className="shortcut-kicker">PAYMENT STATUS</p><h2>Payments are disabled</h2><p>Credits are simulated. No card or bank details are collected, and balances have no cash value. Withdrawal requests are recorded for review.</p></Card>
    </section>

    <section className="wallet-action-grid">
      <Card className="wallet-form-card"><div className="wallet-form-heading"><span className="wallet-form-icon"><ArrowDownLeft size={17}/></span><div><CardTitle>Add practice credits</CardTitle><p>Credits are simulated and added immediately</p></div></div><form onSubmit={event => void submit(event, "deposit")}><label className="label" htmlFor="deposit-amount">Amount</label>{amountInput("deposit-amount", depositAmount, setDepositAmount, busy !== null)}<div className="wallet-quick-amounts">{["10.00", "25.00", "50.00", "100.00"].map(value => <button key={value} type="button" className={depositAmount === value ? "selected" : ""} onClick={() => setDepositAmount(value)} disabled={busy !== null}>€{Number(value)}</button>)}</div><Button className="w-full" disabled={busy !== null || Number(depositAmount) <= 0}>{busy === "deposit" ? "Adding credits…" : "Add credits"}<ArrowDownLeft size={15}/></Button></form></Card>
      <Card className="wallet-form-card" id="withdraw"><div className="wallet-form-heading"><span className="wallet-form-icon brass"><ArrowUpRight size={17}/></span><div><CardTitle>Request a withdrawal</CardTitle><p>Submitted to the admin approval queue</p></div></div><form onSubmit={event => void submit(event, "withdraw")}><label className="label" htmlFor="withdraw-amount">Amount</label>{amountInput("withdraw-amount", withdrawAmount, setWithdrawAmount, busy !== null)}<div className="withdraw-note"><Clock3 size={14}/><span>Your balance stays unchanged while a request is pending.</span></div><Button className="w-full" variant="outline" disabled={busy !== null || Number(withdrawAmount) <= 0}>{busy === "withdraw" ? "Submitting request…" : "Request withdrawal"}<ArrowRightIcon/></Button></form></Card>
    </section>

    <section id="activity" className="section-block wallet-history-section"><div className="section-heading"><div><p className="dashboard-kicker">ACCOUNT RECORD</p><h2>Transaction history</h2></div><span className="section-note">Latest {data?.transactions.length ?? 0} entries</span></div><Card className="activity-card">
      {loading ? <div className="activity-loading"><span className="loading-bar"/><span className="loading-bar"/></div> : !data ? <div className="empty-state"><p>Wallet history could not be loaded.</p></div> : data.transactions.length ? <div className="table-wrap"><table><thead><tr><th>Type</th><th>Movement</th><th>Status</th><th>Date</th></tr></thead><tbody>{data.transactions.map(transaction => <tr key={transaction.id}><td><span className="activity-name"><span className="activity-symbol">{transaction.type.includes("DEPOSIT") ? "+" : transaction.type.includes("WITHDRAW") || transaction.type.includes("BET") ? "−" : "•"}</span>{transaction.type.toLowerCase().replaceAll("_", " ")}</span></td><td>{transaction.entries.map((entry, index) => <span key={index} className={entry.direction === "CREDIT" ? "movement-credit" : "movement-debit"}>{entry.direction === "CREDIT" ? "+" : "−"}{money(entry.amount, entry.currency)}{index < transaction.entries.length - 1 ? " · " : ""}</span>)}</td><td><span className={`status-pill status-${transaction.status.toLowerCase()}`}>{transaction.status}</span></td><td className="activity-date">{new Date(transaction.created_at).toLocaleString(undefined, { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" })}</td></tr>)}</tbody></table></div> : <div className="empty-state"><span className="empty-icon"><CreditCard size={17}/></span><p className="empty-title">No transactions yet</p><p>Your deposits and game activity will appear here.</p></div>}
    </Card></section>

    <section className="section-block wallet-history-section"><div className="section-heading"><div><p className="dashboard-kicker">PENDING REVIEW</p><h2>Withdrawal requests</h2></div></div><Card className="activity-card">
      {loading ? <div className="activity-loading"><span className="loading-bar"/></div> : !data ? <div className="empty-state"><p>Withdrawal requests could not be loaded.</p></div> : data.withdrawals.length ? <div className="table-wrap"><table><thead><tr><th>Request</th><th>Amount</th><th>Status</th><th>Requested</th></tr></thead><tbody>{data.withdrawals.map(withdrawal => <tr key={withdrawal.id}><td>Withdrawal request</td><td>{money(withdrawal.amount, currency)}</td><td><span className={`status-pill status-${withdrawal.status.toLowerCase()}`}>{withdrawal.status}</span></td><td className="activity-date">{new Date(withdrawal.createdAt).toLocaleString()}</td></tr>)}</tbody></table></div> : <div className="empty-state"><p>No withdrawal requests have been submitted.</p></div>}
    </Card></section>
  </PlayerOnly>;
}
function ShieldCheckIcon() { return <BadgeCheck size={17}/>; }
function ArrowRightIcon() { return <ArrowUpRight size={15}/>; }
