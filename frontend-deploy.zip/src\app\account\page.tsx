"use client";

import Link from "next/link";
import { useAuth } from "@/lib/auth";
import { PlayerOnly } from "@/components/require-auth";
import { Card, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, CircleUserRound, ShieldCheck, WalletCards } from "lucide-react";

export default function Account() {
  const { user } = useAuth();
  return <PlayerOnly>
    <div className="dashboard-heading"><div><p className="dashboard-kicker">ACCOUNT SETTINGS</p><h1>Your account</h1><p className="dashboard-subtitle">Profile details and shortcuts to the settings you use.</p></div></div>
    <div className="account-grid">
      <Card className="account-profile-card"><div className="account-profile-icon"><CircleUserRound size={22}/></div><p className="dashboard-kicker">PROFILE</p><CardTitle>Sign-in details</CardTitle><dl className="account-details"><div><dt>Email address</dt><dd>{user?.email ?? "—"}</dd></div><div><dt>Account access</dt><dd>{user?.role === "ADMIN" ? "Administrator" : "Player"}</dd></div></dl></Card>
      <Card className="account-link-card"><span className="account-link-icon"><WalletCards size={18}/></span><div><p className="dashboard-kicker">BALANCE & RECORDS</p><CardTitle>Wallet activity</CardTitle><p>Review your balance, credit requests, withdrawals and game transactions.</p><Button size="sm" variant="outline" asChild><Link href="/cashier">Open wallet <ArrowRight size={14}/></Link></Button></div></Card>
      <Card className="account-link-card"><span className="account-link-icon safety"><ShieldCheck size={18}/></span><div><p className="dashboard-kicker">PLAYER WELLBEING</p><CardTitle>Play controls</CardTitle><p>Manage your limits, set a session reminder or choose time away.</p><Button size="sm" variant="outline" asChild><Link href="/responsible-gambling">Manage controls <ArrowRight size={14}/></Link></Button></div></Card>
    </div>
  </PlayerOnly>;
}
