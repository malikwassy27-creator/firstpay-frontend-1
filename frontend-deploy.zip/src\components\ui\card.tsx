import { cn } from "@/lib/cn";
export function Card({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) { return <div className={cn("bg-white/5 border border-white/10 backdrop-blur-md rounded-2xl p-6", className)} {...props} />; }
export function CardTitle({ className, ...props }: React.HTMLAttributes<HTMLHeadingElement>) { return <h2 className={cn("font-outfit text-lg font-semibold text-white", className)} {...props} />; }
