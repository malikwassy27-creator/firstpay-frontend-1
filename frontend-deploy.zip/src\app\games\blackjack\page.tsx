"use client";

import Link from "next/link";
import { useState } from "react";
import { ArrowLeft, ArrowRight, BadgeCheck, Club, ShieldCheck } from "lucide-react";
import { post } from "@/lib/api";
import { PlayerOnly } from "@/components/require-auth";
import { Card, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

type Round = { round_id: string; server_seed_hash: string };
type PlayingCard = { rank: number; suit: string };
type Result = { result: { player: PlayingCard[]; dealer: PlayingCard[]; player_total: number; dealer_total: number; outcome: "WIN" | "LOSS" | "PUSH"; multiplier: string }; verification: unknown };
const face = (rank: number) => rank === 1 ? "A" : rank === 11 ? "J" : rank === 12 ? "Q" : rank === 13 ? "K" : String(rank);
const isRed = (suit: string) => suit === "♥" || suit === "♦";

export default function Blackjack() {
  const [amount, setAmount] = useState("1.00");
  const [round, setRound] = useState<Round | null>(null);
  const [result, setResult] = useState<Result | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function deal() {
    setBusy(true); setError(""); setResult(null);
    try { setRound(await post<Round>("/games/blackjack/commit", { client_seed: `web-${crypto.randomUUID()}` })); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Could not prepare a hand."); }
    finally { setBusy(false); }
  }
  async function resolve() {
    if (!round) return;
    setBusy(true); setError("");
    try { setResult(await post<Result>("/games/blackjack/resolve", { round_id: round.round_id, amount, idempotency_key: crypto.randomUUID(), bet_type: "blackjack" })); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "The hand could not be settled. Your stake was not confirmed."); }
    finally { setBusy(false); }
  }
  function reset() { setRound(null); setResult(null); setError(""); }
  const payout = result?.result.outcome === "WIN" ? Number(amount) * Number(result.result.multiplier) : result?.result.outcome === "PUSH" ? Number(amount) : 0;

  return <PlayerOnly><Link href="/lobby#games" className="game-back"><ArrowLeft size={15}/> All games</Link><div className="game-page-head"><div><p className="dashboard-kicker">CARD ROOM / TABLE 04</p><h1>Blackjack</h1><p>One player hand against the dealer. The dealer draws to 17; player stands.</p></div></div>
    <div className="new-game-layout"><Card className="card-table"><div className="card-table-heading"><span><Club size={15}/> DEALER SHOWDOWN</span><span>BLACKJACK PAYS 3:2</span></div><div className="card-hand"><p>DEALER <strong>{result ? result.result.dealer_total : "—"}</strong></p><div className="card-row">{result ? result.result.dealer.map((card, index) => <PlayingCard key={index} card={card}/> ) : <div className="card-back">?</div>}</div></div><div className="table-divider"><span>VS</span></div><div className="card-hand"><p>YOUR HAND <strong>{result ? result.result.player_total : "—"}</strong></p><div className="card-row">{result ? result.result.player.map((card, index) => <PlayingCard key={index} card={card}/> ) : <><div className="card-back">A</div><div className="card-back">?</div></>}</div></div>{result && <div className={`card-outcome ${result.result.outcome === "WIN" ? "outcome-win" : result.result.outcome === "LOSS" ? "outcome-loss" : ""}`}><div><span>HAND SETTLED</span><strong>{result.result.outcome === "PUSH" ? "Push · stake returned" : result.result.outcome === "WIN" ? `You win · €${payout.toFixed(2)}` : "Dealer wins this hand"}</strong></div><Link href={`/verify/${round?.round_id}`} className="verify-action">Verify hand <ArrowRight size={14}/></Link></div>}{round && <div className="mines-commitment"><div><ShieldCheck size={14}/> SEED COMMITTED BEFORE DEAL</div><code>{round.server_seed_hash}</code></div>}</Card>
      <Card className="new-game-controls"><div className="bet-panel-heading"><div><p className="dashboard-kicker">ROUND SETUP</p><CardTitle className="mt-2">Place your stake</CardTitle></div><span className="round-icon"><Club size={17}/></span></div><div className="blackjack-rules"><span>Dealer draws until reaching 17</span><span>Your hand stands on the opening deal</span><span>Natural blackjack returns 2.5×</span><span>Equal totals return your stake</span></div><div className="bet-field"><label className="label" htmlFor="blackjack-amount">Stake amount <span>EUR</span></label><div className="amount-control"><button type="button" onClick={() => setAmount((Math.max(.1, Number(amount) / 2)).toFixed(2))} disabled={Boolean(result) || busy}>½</button><input id="blackjack-amount" type="number" min="0.01" step="0.01" value={amount} onChange={event => setAmount(event.target.value)} disabled={Boolean(result) || busy}/><button type="button" onClick={() => setAmount((Number(amount) * 2).toFixed(2))} disabled={Boolean(result) || busy}>2×</button></div></div>{error && <p role="alert" className="error">{error}</p>}{!round ? <Button className="w-full game-primary-action" disabled={busy || Number(amount) <= 0} onClick={() => void deal()}>{busy ? "Committing deck…" : "Commit a fresh deal"}<ArrowRight size={15}/></Button> : !result ? <Button className="w-full game-primary-action" disabled={busy} onClick={() => void resolve()}>{busy ? "Dealer is playing…" : `Deal and settle · €${amount}`}<Club size={15}/></Button> : <Button className="w-full game-primary-action" variant="outline" onClick={reset}>Play another hand <ArrowRight size={15}/></Button>}<div className="bet-security"><BadgeCheck size={14}/><span>Cards and dealer draws are generated from the committed server seed.</span></div></Card></div>
  </PlayerOnly>;
}

function PlayingCard({ card }: { card: PlayingCard }) { return <div className={`playing-card ${isRed(card.suit) ? "red-card" : ""}`}><strong>{face(card.rank)}</strong><span>{card.suit}</span></div>; }
